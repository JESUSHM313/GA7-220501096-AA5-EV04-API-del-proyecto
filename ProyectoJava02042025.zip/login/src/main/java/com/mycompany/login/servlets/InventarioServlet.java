package com.mycompany.login.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "InventarioServlet", urlPatterns = {"/inventario"})
public class InventarioServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        String mensaje = "";
        boolean isPostmanRequest = "application/json".equals(request.getHeader("Accept"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(InventarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String url = "jdbc:mysql://localhost:3306/servletlogin";
        
        try (Connection conexion = DriverManager.getConnection(url, "root", "")) {
            if ("agregar".equals(accion)) {
                String nombre = request.getParameter("nombre");
                String descripcion = request.getParameter("descripcion");
                String sql = "INSERT INTO inventario (nombre, descripcion) VALUES (?, ?)";
                PreparedStatement ps = conexion.prepareStatement(sql);
                ps.setString(1, nombre);
                ps.setString(2, descripcion);
                int filas = ps.executeUpdate();
                mensaje = filas > 0 ? "Ítem agregado exitosamente." : "Error al agregar ítem.";
                
            } else if ("modificar".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String nombre = request.getParameter("nombre");
                String descripcion = request.getParameter("descripcion");
                String sql = "UPDATE inventario SET nombre = ?, descripcion = ? WHERE id = ?";
                PreparedStatement ps = conexion.prepareStatement(sql);
                ps.setString(1, nombre);
                ps.setString(2, descripcion);
                ps.setInt(3, id);
                int filas = ps.executeUpdate();
                mensaje = filas > 0 ? "Ítem modificado exitosamente." : "Error al modificar ítem.";
                
            } else if ("eliminar".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String sql = "DELETE FROM inventario WHERE id = ?";
                PreparedStatement ps = conexion.prepareStatement(sql);
                ps.setInt(1, id);
                int filas = ps.executeUpdate();
                mensaje = filas > 0 ? "Ítem eliminado exitosamente." : "Error al eliminar ítem.";
            }
            
            if (isPostmanRequest) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                try (PrintWriter out = response.getWriter()) {
                    out.write("{\"message\":\"" + mensaje + "\"}");
                    out.flush();
                }
            } else {
                response.sendRedirect("panel.jsp?mensaje=" + mensaje);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(InventarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    // ✅ Nuevo Método GET para recibir datos en formato JSON
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        boolean isPostmanRequest = "application/json".equals(request.getHeader("Accept"));
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String url = "jdbc:mysql://localhost:3306/servletlogin";
        
        try (Connection conexion = DriverManager.getConnection(url, "root", "");
             PrintWriter out = response.getWriter()) {
            
            String sql = "SELECT * FROM inventario";
            PreparedStatement ps = conexion.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            JSONArray jsonArray = new JSONArray();
            
            while (rs.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", rs.getInt("id"));
                jsonObject.put("nombre", rs.getString("nombre"));
                jsonObject.put("descripcion", rs.getString("descripcion"));
                jsonArray.put(jsonObject);
            }
            
            out.print(jsonArray.toString());
            out.flush();
            
        } catch (SQLException ex) {
            Logger.getLogger(InventarioServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.write("{\"message\":\"Error al recuperar inventario: " + ex.getMessage() + "\"}");
                out.flush();
            }
        }
    }
}
