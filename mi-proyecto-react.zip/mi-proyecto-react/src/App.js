// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Panel from './components/Panel';
import Inventario from './components/Inventario';  // Importa tu nuevo componente

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/panel" element={<Panel />} />
        <Route path="/inventario" element={<Inventario />} />  {/* Nueva ruta para Inventario */}
      </Routes>
    </Router>
  );
}

export default App;
