// src/components/Panel.jsx
import React from 'react';

const Panel = () => {
  return (
    <div>
      <h2>Panel de Usuario</h2>
      <p>Bienvenido al panel.</p>
    </div>
  );
};

export default Panel;
